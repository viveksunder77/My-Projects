rows=0
columns=0
details=dict()
seating_order=[]
tickets=0