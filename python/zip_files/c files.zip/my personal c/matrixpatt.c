#include<stdio.h>
void main(){
    int costs[5][5];
    printf("enter the costs : ");
    for(int i=0;i<5;i++)
    for(int j=0;j<5;j++)
    scanf("%d",&costs[i][j]);
    printf("\n");
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(j==i){
               printf(" %d ",costs[i][j]);
            }
            else{
                printf(" ");
            }
        }
        printf("\n");
    }
    printf("\n");
    printf("\n");
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(j<i){
               printf(" %d ",costs[i][j]);
            }
            else{
                printf(" ");
            }
        }
        printf("\n");
    }
}