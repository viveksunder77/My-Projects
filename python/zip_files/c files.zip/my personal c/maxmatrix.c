#include<stdio.h>
void main(){
    int max=0,costs[5][5];
    printf("enter the costs of all purchaes \n");
    for(int i=0;i<5;i++)
    for(int j=0;j<5;j++)
    {
     scanf("%d",&costs[i][j]);
     if(max<costs[i][j]){
         max=costs[i][j];
     }
    }
    printf("the maximum cost is : %d",max);
    
}