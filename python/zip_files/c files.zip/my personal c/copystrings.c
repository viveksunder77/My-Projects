#include<stdio.h>
void main(){
    int n;
    printf("enter the size of the string : ");
    scanf("%d",&n);
    char string1[n],string2[n];
    printf("enter the string : ");
    scanf("%s",&string1);
    for(int i=0;i<n;i++)
    string2[i]=string1[i];
    printf("the copied string is : ");
    for(int i=0;i<n;i++){
        printf("%c",string2[i]);
    }
}