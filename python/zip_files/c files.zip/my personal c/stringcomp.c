#include<stdio.h>
#include<string.h>
void main(){
    char string1[20],string2[20];
    printf("enter the first string : ");
    scanf("%s", string1);
    printf("enter the second string : ");
    scanf("%s", string2);
    if(strcmp(string1,string2)==0){
        printf("both are same ");
    }
    else{
        printf("both are not same ");
    }
}