#include<stdio.h>
int multiplication(int a,int b){
    return a*b;
}
float circle(int radius){
    return 3.14*radius*radius;
}
void iseven(int number){
    if(number%2==0)
    printf("the number is even \n");
    else
    printf("the number is odd \n");
}
int fact(int n){
    int f=1;
    for(int i=1;i<=n;i++)
    f=f*i;
    return f;
}
int smallest(int a,int b,int c){
    if(a<b && a<c)
     return a;
    else if(b<c)
    return b;
    else
    return c;
}
void main(){
 int choice,a,b,c;
 printf("1.multiplication \n2.area of circle \n3.even or odd \n4.factorial\n 5.smallest \n");
 scanf("%d",&choice);
 switch(choice){
     case 1:printf("enter the two numbers : \n");
     scanf("%d %d",&a,&b);
     printf("the answer is : %d \n",multiplication(a,b));
     break;
     case 2:printf("enter the radius : ");
     scanf("%d",&a);
     printf("the answer is : %d \n",circle(a));
     break;
     case 3:printf("enter the number : ");
     scanf("%d",&a);
     iseven(a);
     break;
     case 4:printf("enter the number : ");
     scanf("%d",&a);
     printf("the factorial is : %d \n",fact(a));
     break;
     case 5:printf("enter the numbers : \n");
     scanf("%d %d %d",&a,&b,&c);
     printf("the smallest is : %d ",smallest(a,b,c));
     break;
     default:
     printf("Exit");
            
 }
}