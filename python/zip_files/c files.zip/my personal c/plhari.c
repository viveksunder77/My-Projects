#include<stdio.h>
void main(){
    int plari[4][5],hari[5],priya[5],poorna[5],chandra[5];
    printf("enter the contents of the plhari \n");
    for(int i=0;i<4;i++)
    for(int j=0;j<5;j++)
    scanf("%d",&plari[i][j]);
    for(int i=0;i<4;i++){
        for(int j=0;j<5;j++){
            if(i==0){
                hari[i]=plari[i][j];
            }
            else if(i==1){
                priya[i]=plari[i][j];
            }
            else if(i==2){
                poorna[i]=plari[i][j];
            }
            else{
                chandra[i]=plari[i][j];
            }
        }
    }
    printf("the contents of hari are : ");
    for(int i=0;i<5;i++)
    printf(" %d ",hari[i]);
    printf("\nthe contents of priya are : ");
    for(int i=0;i<5;i++)
    printf(" %d ",priya[i]);
    printf("\nthe contents of poorna are : ");
    for(int i=0;i<5;i++)
    printf(" %d ",poorna[i]);
    printf("\nthe contents of chandra are : ");
    for(int i=0;i<5;i++)
    printf(" %d ",chandra[i]);
}