#include<stdio.h>
void main(){
    int lottery[5],karan,i;
    printf("enter the lottery numbers : \n" );
    for(int i=0;i<5;i++)
    scanf("%d",&lottery[i]);
    printf("enter the karan lottery number : ");
    scanf("%d",&karan);
    for( i=0;i<5;i++){
        if(lottery[i]==karan)
        {
           printf("karan won the lottery \n ");
           break;
        }
    }
    if(i==5)
    printf("he didnt win the lottery \n");
}