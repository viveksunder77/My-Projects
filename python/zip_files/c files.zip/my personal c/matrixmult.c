#include<stdio.h>
void main(){
    int m,n,q,r;
    printf("enter the size of the first matrix : ");
    scanf("%d %d",&m,&n);
    printf("enter the size of the second matrix : ");
    scanf("%d %d",&q,&r);
    int first[m][n];
    int second[q][r];
    printf("enter the values of the first matrix \n");
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            scanf("%d",&first[i][j]);
        }
    }
    printf("enter the values of the second matrix \n");
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            scanf("%d",&second[i][j]);
        }
    }
    if(n==q){
        int result[m][r],sum=0;
        for(int i=0;i<m;i++){
            for(int j=0;j<r;j++){
                for(int k=0;k<q;k++){
                    sum=sum+first[i][k]*second[k][j];
                }
                result[i][j]=sum;
                sum=0;
            }
        }
        printf("the final result matrix is : \n");
        for(int i=0;i<m;i++)
        {
        for(int j=0;j<r;j++)
        printf("%d ",result[i][j]);
        printf("\n");
        }
    }
}