#include<stdio.h>
void main(){
    int heights[10],temp;
    printf("enter the heights of the students : \n");
    for(int i=0;i<10;i++)
    {
    printf("enter the height of student %d : ",i+1);
    scanf("%d",&heights[i]);
    }
    for (int i=0;i<9;i++)
  {
    for (int j=0;j<10-i-1;j++)
    {
      if (heights[j]>heights[j+1]) 
      {
        temp=heights[j];
        heights[j]=heights[j+1];
        heights[j+1]=temp;
      }
    }
  }
    printf("asending order of heights for the assemebly : ");
    for(int i=0;i<10;i++)
    printf(" %d ",heights[i]);
}
